# Integración de Data Analyzer en QuOLab Nexus 2.0

Data Analyzer (versión **#5**, identificador interno `0.5-fase1-p3`) es ahora una aplicación del ecosistema: una tarjeta **📊 DATA ANALYZER** en el menú principal abre un entorno propio, con su navegación y herramientas, y un botón **← MENU** para volver.

## 1. Auditoría (resumen)

**QuOLab Nexus 2.0.** Sitio estático sin build. `index.html` es el *shell*: cabecera, menú de tarjetas, pantallas `.screen` y un objeto `QuOLabNexus` (módulo ES). Cada herramienta es un HTML independiente (`quolab-nexus-*.html`) que el shell carga en un `<iframe>` del mismo origen bajo demanda (`MODULES` → `loadModule()` → `iframes[...]`). Navegación: `nav(screen)`, pila `_navStack`, enlaces `#pantalla` (`routeFromHash`), botón compartir y atajos de teclado globales. El workflow `deploy-pages.yml` publica `index.html`, `quolab-nexus-*.html` y `quolab-nexus-*.js`.

**Data Analyzer #5.** Un único HTML autocontenido (~142 KB), sin dependencias propias salvo Plotly por CDN (carga diferida). Capas: Workbooks/Worksheets (`DM`, `WorkbookManager`, `WorksheetManager`, `VariableManager`), editor de hojas (`Editor`), análisis (`AData`, `AStats`, `ACorr`, `AChart`, `Analysis`) y el analizador de archivos de la Fase 0 (File Explorer → Analizar). Su CSS es global (`*`, `body`, `button`…).

## 2. Diseño elegido

**Módulo en iframe**, igual que Projects, Quantum Open Lab, Library o Quantum Puzzle. Motivos:

- El aislamiento del iframe evita cualquier conflicto de CSS global, nombres (`go`, `save`, `log`, `Store`…) y scripts entre ambos proyectos. Reescribir Data Analyzer como sección de `index.html` habría exigido renombrar cientos de símbolos.
- Es la convención del propio Nexus: carga bajo demanda, mismo origen, enlaces `#data-analyzer`, mismo botón de regreso.
- El workflow de Pages ya publica `quolab-nexus-*.html`, así que **no cambia el despliegue**.

Descartado: fusionar el código en `index.html` (riesgo alto, sin beneficio) y alojarlo en un subdirectorio (el workflow no lo copiaría sin modificarlo).

## 3. Archivos

| Archivo | Cambio |
|---|---|
| `quolab-nexus-data-analyzer.html` | **Nuevo.** Data Analyzer #5 con 4 adaptaciones mínimas (ver §5). |
| `index.html` | **Modificado** (+36/−1 líneas, parche en `docs/data-analyzer-integration.index.patch`): entrada en `MODULES`, pantalla `screen-data-analyzer`, tarjeta de menú, texto de *placeholder*, alias de enlace (`#analyzer`, `#data`, `#dataanalyzer`) y exención del manejador de teclado global para este módulo. |
| `tests/quolab-nexus-data-analyzer.test.cjs` | **Nuevo.** Comprobaciones estáticas (se ejecuta como el resto de tests de `tests/`). |
| `tests/e2e/data_analyzer_e2e.py` | **Nuevo.** Prueba end-to-end en Chromium (Playwright). |
| `docs/DATA_ANALYZER_INTEGRATION.md` | **Nuevo.** Este documento. |

No se tocó: workflow de Pages, backend, Supabase, módulos existentes, `quolab-nexus-agent.js`, ni la lista de pantallas de QNexusAi.

## 4. Navegación

- **Entrada:** tarjeta del menú, o enlace directo `…/index.html#data-analyzer`.
- **Dentro:** el menú propio de Data Analyzer (hamburguesa/lateral): File Explorer, Dashboard, Data Analyzer, etc. En modo embebido arranca directamente en el espacio de trabajo de análisis.
- **Regreso:** **← MENU** en la cabecera de la pantalla (y Esc/«atrás» del shell cuando el foco está fuera del módulo). La sesión de Data Analyzer (Workbooks, hojas, resultados) se conserva en memoria mientras la pestaña esté abierta, porque el iframe queda en caché al volver al menú.
- **Modo independiente:** abrir `quolab-nexus-data-analyzer.html` directamente muestra la portada original y un enlace **← QuOLab Nexus** hacia `index.html`.

## 5. Adaptaciones en Data Analyzer (respecto a #5)

1. Detección de entorno: `window.NX_EMBEDDED` y clase `nx-embedded` en `<html>`.
2. En modo embebido: se oculta la pantalla de bienvenida, se alinean fondo y color de acento con Nexus (`--bg:#010608; --ac:#00ccff`) y se abre `Data Analyzer` en vez de la portada.
3. En modo independiente: enlace «← QuOLab Nexus».
4. `Settings` informa de `integracion_nexus` (módulo, modo, y que la comunicación con otros módulos **no está implementada**).

Todo está marcado con el comentario «Integración Nexus» o el bloque CSS «Integración QuOLab Nexus 2.0». Para actualizar a una versión futura de Data Analyzer, reaplique esos 4 puntos (`grep -n "NX_EMBEDDED\|nxback\|nx-embedded"`).

## 6. Incompatibilidades detectadas y solución

| Problema | Solución |
|---|---|
| El manejador de teclado global de Nexus (flechas = navegación espacial, Esc = atrás, H/S = inicio/compartir) se engancha en los iframes del mismo origen y **interceptaba las flechas y Esc dentro de la hoja** de Data Analyzer. | `attachKeys()` no se engancha al iframe `data-openq="data-analyzer"`. Fuera del módulo los atajos siguen igual; dentro, el editor usa su propio teclado. Contrapartida: Alt+H y Esc no actúan con el foco dentro de Data Analyzer (use **← MENU**). |
| Estilos globales de Data Analyzer. | Sin acción: el iframe los aísla. |
| Nombres globales (`go`, `save`, `log`, `Store`, `STATE`…). | Sin acción: contexto JS independiente. |
| `localStorage`/IndexedDB comparten origen con Nexus. | Sin colisión: Data Analyzer usa el prefijo `quolab.v1.*` y la base `quolab-data`; Nexus usa claves `openq_*`/`qcol_*`. |

## 7. Qué es real y qué es futuro

**Real (versión #5, verificado en navegador):** Workbooks y Worksheets; creación de tablas; edición de celdas, filas y columnas; metadatos de variables (nombre, unidad, tipo, naturaleza, rol X/Y/Z/incertidumbre/id); importación de archivos hacia hojas; estadística descriptiva; correlación de Pearson y Spearman; gráficos (dispersión, líneas, histograma, barras, box plot) con exportación PNG/SVG; resultados en memoria con estado «vigente/desactualizado»; exportación CSV/JSON/informe HTML; analizador de archivos de la Fase 0 (incluye la sección «Fórmulas y convenciones»).

**No existe todavía (no se ha simulado):** deshacer/«Volver atrás», ajustes de modelos sobre el gráfico (lineal/exponencial/R²/residuos), selección guiada de variables X/Y/Z en un único flujo, comunicación con otros módulos de QuOLab, envío de datos a circuitos, VQE/QAE/QAOA. La integración deja el punto de enganche previsto: el protocolo `QuOLabNexusCore` (`NEXUS_*`, `sendToParent`) que ya usan los demás módulos.

## 8. Validación

- 34 comprobaciones end-to-end en Chromium real (`tests/e2e/data_analyzer_e2e.py`): tarjeta en el menú; apertura; modo embebido; enlace `#data-analyzer` y alias; flujo completo (workbook → tabla → 22 celdas por teclado → metadatos → estadística → correlación → gráfico de dispersión con 11 puntos; los otros 4 tipos de gráfico se construyen); valores contrastados con cálculo independiente (media 445,909…, desv. muestral 284,388…, Pearson −0,96447…, Spearman −1); regreso al menú y reapertura conservando datos; apertura de los 6 módulos existentes (projects, architect, architect-pro, library, help, quantum-puzzle); modo independiente; despliegue en subruta (`/repo/index.html`), como en GitHub Pages.
- `tests/*.cjs`: los 3 tests existentes siguen pasando y se añade el nuevo.
- Sintaxis de todos los bloques `<script>` comprobada; simulación del paso de ensamblado de Pages: el módulo entra en `dist/`.
- Limitaciones de la prueba: se ejecutó sin red, con CodeMirror/marked sustituidos por stubs y Plotly servido en local; Supabase, KaTeX y fuentes se bloquearon. **No** se ha probado en GitHub Pages real ni en móvil, ni el panel QNexusAi, Login/Founder, ni el compilador cuántico.

## 9. Asuntos abiertos (requieren su decisión)

1. **IndexedDB.** Data Analyzer #5 persiste Workbooks/Worksheets en IndexedDB (`quolab-data`), contra la decisión de mantenerlos solo en memoria. No se ha cambiado para no alterar su comportamiento sin autorización; corresponde a la versión #6. Mientras tanto, los datos científicos persisten en el navegador del usuario.
2. **Pérdida de pulsaciones** al teclear a velocidad de máquina en el editor (la confirmación de celda es asíncrona). Ocurre también en Data Analyzer independiente, por lo que es del editor #5, no de la integración; con pausas de ~80 ms funciona bien.
3. **Mensaje heredado** «Selecciona un archivo en File Explorer» en la sección Data Analyzer (ya identificado en #5).
4. **QNexusAi** no conoce este módulo (no está en `AI_SCREENS` ni en el agente) y por eso la cabecera no incluye el botón de IA. Añadirlo exige definir sus herramientas en `quolab-nexus-agent.js`.
5. **Plotly** se carga desde `cdn.jsdelivr.net` (requiere conexión para los gráficos; el resto funciona sin ella).
