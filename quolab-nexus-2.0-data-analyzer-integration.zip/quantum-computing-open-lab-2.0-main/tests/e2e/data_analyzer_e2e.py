"""Prueba end-to-end (Chromium real) de la integración Data Analyzer <-> QuOLab Nexus.
Requisitos: pip install playwright && playwright install chromium ; npm i plotly.js-dist-min@2.35.2
Uso (desde la raíz del repo):
    python3 -m http.server 8765 &
    PLOTLY_JS=node_modules/plotly.js-dist-min/plotly.min.js python3 tests/e2e/data_analyzer_e2e.py
Las dependencias externas (esm.sh, Plotly CDN) se sustituyen por stubs/ficheros locales para que la prueba sea determinista y sin red;
el resto de servicios externos (Supabase, fuentes, KaTeX) se bloquean.
"""
import json, math, sys, os
from playwright.sync_api import sync_playwright

BASE=os.environ.get("NEXUS_URL","http://localhost:8765/")
PLOTLY=open(os.environ.get("PLOTLY_JS","plotly.min.js"),"rb").read()
CM_STUB="""export class EditorView{constructor(o){this.dom=document.createElement('div');this.state={doc:{toString:()=>''}};if(o&&o.parent)o.parent.appendChild(this.dom)}
static get updateListener(){return {of(){return []}}} static get theme(){return ()=>[]} static get lineWrapping(){return []} static get domEventHandlers(){return ()=>[]} dispatch(){} focus(){} destroy(){} }
export const basicSetup=[]; export function markdown(){return []}
export const marked={parse:s=>String(s)}; export default {};"""
results=[]; fails=[]
def check(name, cond, detail=""):
    results.append((name,bool(cond),detail)); 
    if not cond: fails.append(name)
    print(("PASS " if cond else "FAIL ")+name+(" — "+str(detail) if detail else ""))

def route(r):
    u=r.request.url
    if u.startswith("http://localhost:8765"): return r.continue_()
    if "esm.sh" in u: return r.fulfill(status=200,content_type="application/javascript",body=CM_STUB)
    if "plotly" in u: return r.fulfill(status=200,content_type="application/javascript",body=PLOTLY)
    return r.abort()

with sync_playwright() as p:
    b=p.chromium.launch(); ctx=b.new_context(viewport={"width":1280,"height":900}); ctx.route("**/*",route)
    page=ctx.new_page(); errs=[]
    page.on("pageerror",lambda e:errs.append("host:"+str(e)))
    page.goto(BASE+"index.html"); page.wait_for_function("window.QuOLabNexus!==undefined",timeout=15000)
    # splash
    page.evaluate("(()=>{const s=document.getElementById('splash'); if(s) s.style.display='none'})()")
    page.evaluate("QuOLabNexus.nav('home')")
    # 1 menu card
    cards=page.eval_on_selector_all("#menu-grid .menu-card .card-title","e=>e.map(x=>x.textContent.trim())")
    check("Menú principal incluye DATA ANALYZER", any("DATA ANALYZER" in c for c in cards), cards)
    check("Se conservan las 7+ tarjetas previas", sum(1 for c in cards if any(k in c for k in ["PROJECTS","QUANTUM OPEN LAB","NOTEBOOK","LIBRARY","MY ACCOUNT","HELP","PUZZLE"]))>=7, len(cards))
    # 2 abrir
    page.click("#menu-grid .menu-card:has-text('DATA ANALYZER')")
    page.wait_for_selector("#screen-data-analyzer.active")
    page.wait_for_selector("iframe[data-openq='data-analyzer']",timeout=8000)
    fl=page.frame_locator("iframe[data-openq='data-analyzer']")
    fl.locator("#wbp").wait_for(timeout=8000)
    fr=[f for f in page.frames if "quolab-nexus-data-analyzer" in f.url][0]
    page.wait_for_timeout(500)
    check("Data Analyzer carga dentro del ecosistema (iframe)", fr.evaluate("window.NX_EMBEDDED===true && document.documentElement.classList.contains('nx-embedded')"))
    check("Splash de DA oculto en modo embebido", fr.evaluate("getComputedStyle(document.getElementById('welcome')).display==='none'"))
    check("Botón 'volver' interno oculto en modo embebido", fr.evaluate("getComputedStyle(document.querySelector('.nxback')).display==='none'"))
    check("URL con hash #data-analyzer", page.evaluate("location.hash")=="#data-analyzer", page.evaluate("location.hash"))
    check("Botón compartir visible en DA", page.evaluate("getComputedStyle(document.getElementById('share-fab')).display")!="none")
    # 3 flujo de trabajo real
    fl.get_by_role("button",name="+ Workbook").click(); fl.locator("#dlgok").click()
    fl.get_by_role("button",name="Nueva tabla…").click()
    ins=fl.locator("#dlg input"); ins.nth(0).fill("Desintegración"); ins.nth(1).fill("2"); ins.nth(2).fill("11"); fl.locator("#dlgok").click()
    fl.locator("#edGrid td[data-r='0'][data-c='0']").wait_for()
    T=[0,10,20,30,40,50,60,70,80,90,100]; A=[1000,819,670,549,449,368,301,247,202,165,135]
    fl.locator("#edGrid td[data-r='0'][data-c='0']").click()
    for v in T: page.keyboard.type(str(v)); page.keyboard.press("Enter"); page.wait_for_timeout(80)
    fl.locator("#edGrid td[data-r='0'][data-c='1']").click()
    for v in A: page.keyboard.type(str(v)); page.keyboard.press("Enter"); page.wait_for_timeout(80)
    got=fr.evaluate("(()=>{const s=STATE.sheets.get(WorkbookManager.active().activeSheetId).table;return s.columns.map(c=>c.values)})()")
    check("Edición de celdas por teclado: datos correctos y emparejados", got==[T,A], got)
    # teclado: flechas no secuestradas, Esc no vuelve al menú
    fl.locator("#edGrid td[data-r='2'][data-c='0']").click()
    page.keyboard.press("ArrowRight"); page.keyboard.press("ArrowDown")
    act=fr.evaluate("(()=>{const S=Editor.S();return [S.a.r,S.a.c]})()")
    check("Flechas mueven la celda activa (no las intercepta QuOLab)", act==[3,1], act)
    page.keyboard.press("Escape")
    check("Esc dentro de la hoja no expulsa al menú", page.evaluate("document.querySelector('.screen.active').id")=="screen-data-analyzer")
    # metadatos
    for c,(nm,un,rl) in enumerate([("Tiempo","s","X"),("Actividad","cuentas/min","Y")]):
        fl.locator(f"#edGrid th.nm[data-c='{c}']").click()
        fl.locator("#pp_short").fill(nm); fl.locator("#pp_unit").fill(un); fl.locator("#pp_role").select_option(rl)
        fl.get_by_role("button",name="Aplicar").click(); page.wait_for_timeout(150)
    meta=fr.evaluate("(()=>{const t=STATE.sheets.get(WorkbookManager.active().activeSheetId).table;return t.columns.map(c=>[c.shortName,c.unit,c.role])})()")
    check("Metadatos de variables (nombre, unidad, rol X/Y)", meta==[["Tiempo","s","X"],["Actividad","cuentas/min","Y"]], meta)
    # estadística
    fl.locator("#anx input[type=checkbox]").nth(0).check(); fl.locator("#anx input[type=checkbox]").nth(1).check()
    fl.get_by_role("button",name="Calcular para las variables marcadas").click(); page.wait_for_timeout(200)
    mean=fr.evaluate("(()=>{const r=Analysis.results.find(x=>x.kind=='stats');return r.payload.rows.map(x=>[x.name,x.stats.mean,x.stats.sdS,x.stats.median])})()")
    expA=sum(A)/11; sdA=math.sqrt(sum((a-expA)**2 for a in A)/10)
    check("Estadística descriptiva correcta (media/desv. de Actividad)", abs(mean[1][1]-expA)<1e-9 and abs(mean[1][2]-sdA)<1e-9 and mean[1][3]==368, mean[1])
    # correlación
    fl.get_by_role("button",name="Correlación").first.click()
    sel=fl.locator("#anx select"); 
    n=sel.count()
    fr.evaluate("(()=>{const s=STATE.sheets.get(WorkbookManager.active().activeSheetId).table.columns;Analysis.px=s[0].id;Analysis.py=s[1].id;Analysis.runCorr()})()"); page.wait_for_timeout(200)
    r=fr.evaluate("Analysis.results.find(x=>x.kind=='corr').payload")
    mt=sum(T)/11; num=sum((t-mt)*(a-expA) for t,a in zip(T,A)); den=math.sqrt(sum((t-mt)**2 for t in T)*sum((a-expA)**2 for a in A)); pr=num/den
    check("Correlación de Pearson correcta", abs(r["pearson"]-pr)<1e-9 and r["n"]==11, (r["pearson"],pr))
    check("Spearman = -1 (relación estrictamente monótona)", abs(r["spearman"]+1)<1e-9, r["spearman"])
    # gráfico
    fr.evaluate("(()=>{const s=STATE.sheets.get(WorkbookManager.active().activeSheetId).table.columns;Analysis.tab='ch';Analysis.cfg={...BLANK,type:'scatter',x:s[0].id,ys:[s[1].id],title:'Decaimiento'};Analysis.render()})()")
    fl.get_by_role("button",name="Generar gráfico").click(); 
    fl.locator("#anChart .js-plotly-plot, #anChart.js-plotly-plot").first.wait_for(timeout=8000)
    pts=fr.evaluate("(()=>{const e=document.getElementById('anChart');return [e.data.length,e.data[0].x.length,e.data[0].y[0]]})()")
    check("Gráfico de dispersión generado con Plotly (11 puntos)", pts==[1,11,1000], pts)
    for t in ["hist","line","box","bar"]:
        ok=fr.evaluate("""async(t)=>{const s=STATE.sheets.get(WorkbookManager.active().activeSheetId).table.columns;try{const cfg={...BLANK,type:t,x:t=='hist'||t=='line'?s[0].id:'',ys:t=='hist'?[]:[s[1].id]};if(t=='hist')cfg.x=s[1].id;const f=AChart.build(STATE.sheets.get(WorkbookManager.active().activeSheetId),cfg);return f.data.length>0}catch(e){return String(e)}}""",t)
        check(f"Gráfico tipo '{t}' se construye", ok is True, ok)
    # estado en memoria / exportación
    check("Resultados guardados en memoria (3+)", fr.evaluate("Analysis.results.length")>=3)
    # 4 volver y reabrir
    page.click("#screen-data-analyzer .btn-back"); page.wait_for_selector("#screen-home.active")
    check("Regreso a QuOLab con '← MENU'", page.evaluate("location.hash")=="")
    page.click("#menu-grid .menu-card:has-text('DATA ANALYZER')"); page.wait_for_selector("#screen-data-analyzer.active"); page.wait_for_timeout(400)
    fr=[f for f in page.frames if "quolab-nexus-data-analyzer" in f.url][0]
    check("Al reabrir, DA conserva su sesión (workbooks/resultados en memoria)", fr.evaluate("STATE.wbs.size==1 && Analysis.results.length>=3"))
    # 5 regresión de otros módulos
    for sc in ["projects","architect","architect-pro","library","help","quantum-puzzle"]:
        page.evaluate(f"QuOLabNexus.nav('{sc}')")
        try:
            page.wait_for_selector(f"iframe[data-openq='{sc}']",timeout=6000,state="attached")
            ok=page.evaluate(f"document.querySelector('.screen.active').id==='screen-{sc}'")
        except Exception as e: ok=False
        check(f"Módulo existente '{sc}' sigue abriendo", ok)
    page.evaluate("QuOLabNexus.nav('home')")
    # 6 deep link
    p2=ctx.new_page(); p2.on("pageerror",lambda e:errs.append("p2:"+str(e)))
    p2.goto(BASE+"index.html#data-analyzer"); p2.wait_for_function("window.QuOLabNexus!==undefined",timeout=15000)
    p2.evaluate("(()=>{const s=document.getElementById('splash'); if(s) s.style.display='none'})()")
    p2.wait_for_timeout(800)
    check("Enlace directo #data-analyzer abre el módulo", p2.evaluate("document.querySelector('.screen.active')?.id")=="screen-data-analyzer", p2.evaluate("document.querySelector('.screen.active')?.id"))
    p3=ctx.new_page(); p3.goto(BASE+"index.html#analyzer"); p3.wait_for_function("window.QuOLabNexus!==undefined",timeout=15000); p3.wait_for_timeout(800)
    check("Alias #analyzer funciona", p3.evaluate("document.querySelector('.screen.active')?.id")=="screen-data-analyzer")
    # 7 standalone
    p4=ctx.new_page(); perr=[]; p4.on("pageerror",lambda e:perr.append(str(e))); p4.goto(BASE+"quolab-nexus-data-analyzer.html"); p4.wait_for_timeout(600)
    check("Standalone: NX_EMBEDDED=false, splash y enlace de regreso visibles", p4.evaluate("window.NX_EMBEDDED===false && getComputedStyle(document.getElementById('welcome')).display!=='none' && getComputedStyle(document.querySelector('.nxback')).display!=='none'"))
    p4.click("#enter"); p4.wait_for_timeout(1000)
    check("Standalone: enlace '← QuOLab Nexus' apunta a index.html", p4.get_attribute(".nxback","href")=="index.html")
    check("Sin errores JS en DA standalone", not perr, perr)
    check("Sin errores JS de página en QuOLab", not [e for e in errs], errs[:3])
    b.close()

print("\nTOTAL",len(results),"FALLOS",len(fails),fails)
sys.exit(1 if fails else 0)
