// Comprobaciones estáticas de la integración de Data Analyzer en QuOLab Nexus 2.0.
const fs = require("node:fs");
const assert = require("node:assert/strict");
const read = (p) => fs.readFileSync(p, "utf8");

const index = read("index.html");
const da = read("quolab-nexus-data-analyzer.html");
const pages = read(".github/workflows/deploy-pages.yml");

// 1) Registro del módulo, pantalla, tarjeta y enlace directo
assert.match(index, /'data-analyzer'\s*:\s*'quolab-nexus-data-analyzer\.html'/);
assert.match(index, /id="screen-data-analyzer"/);
assert.match(index, /id="data-analyzer-wrap"/);
assert.match(index, /screen:'data-analyzer'/);
assert.match(index, /analyzer:\s*'data-analyzer'/);
const start = index.indexOf('id="screen-data-analyzer"');
const block = index.slice(start, index.indexOf('data-analyzer-wrap', start));
assert.ok(block.includes("QuOLabNexus.nav('home')"), "la pantalla debe tener botón de regreso al menú");   // regreso al ecosistema
assert.ok(block.includes("DATA ANALYZER"), "la pantalla debe estar identificada como DATA ANALYZER");

// 2) El manejador global de teclado no debe interceptar la hoja de Data Analyzer
assert.match(index, /getAttribute\('data-openq'\) === 'data-analyzer'\) return;/);

// 3) Los módulos existentes siguen registrados
for (const id of ["projects", "architect", "architect-pro", "library", "account", "founder", "help", "quantum-puzzle"]) {
  assert.ok(index.includes(`id="screen-${id}"`), `falta la pantalla ${id}`);
}

// 4) Data Analyzer: modo embebido, enlace de regreso en modo independiente y funcionalidad conservada
assert.match(da, /window\.NX_EMBEDDED/);
assert.match(da, /class="nxback" href="index\.html"/);
for (const sym of ["WorkbookManager", "WorksheetManager", "VariableManager", "Editor", "AStats", "ACorr", "AChart", "Analysis", "ImportBridge"]) {
  assert.ok(da.includes("const " + sym), `Data Analyzer perdió ${sym}`);
}

// 5) Despliegue: el workflow de Pages publica quolab-nexus-*.html (incluye el módulo) y no necesita cambios
assert.match(pages, /cp quolab-nexus-\*\.html dist\//);

// 6) Sin conexiones ficticias con el motor cuántico en el módulo
assert.doesNotMatch(da, /\/run\/predict|qiskit\.|supabase\.co/i);

console.log("quolab-nexus-data-analyzer: OK");
